MusicNetEM labels for the MusicNet dataset

© Ben Maman (Tel Aviv University) and Amit Bermano (Tel Aviv University) 2022.
License applies to MusicNetEM, and not to the MusicNet dataset. 
Usage of any part of the original MusicNet dataset (including recordings, unaligned MIDI, 
and original aligned MIDI) is under the terms of the MusicNet dataset license.

MusicNetEM are refined labels for the MusicNet dataset, in the form of MIDI files. 
They are aligned with the recordings, with onset timing within 32ms. 
They were created using an EM process, similar to the one described in the paper: 
Ben Maman and Amit H. Bermano, "Unaligned Supervision for Automatic Music Transcription in The Wild".

The original MusicNet dataset was published by John Thickstun, Zaid Harchaoui, and Sham M. Kakade, 
in the paper: 
Thickstun et al., "Learning Features of Music from Scratch", ICLR 2017.

The difference between the original MusicNet labels and our MusicNetEM labels:

- MusicNet labels were obtained by aligning MIDI with audio according to spectral features of the audio
and the synthesized MIDI, as described in the paper:
Thickstun et al., "Learning Features of Music from Scratch", ICLR 2017.

- MusicNetEM labels were obtained by aligning MIDI with audio according to network predictions,
with an EM process, as described in the paper:
Ben Maman and Amit H. Bermano, "Unaligned Supervision for Automatic Music Transcription in The Wild".


MusicNet Recordings available at: https://www.kaggle.com/datasets/imsparsh/musicnet-dataset

